package com.example.demo;

import org.springframework.stereotype.Controller;

@Controller
public class MyController{
	
	@RequestMapping("/test1")
	public String test1(
			HttpServletRequest httpServletRequest,
			
			)
}